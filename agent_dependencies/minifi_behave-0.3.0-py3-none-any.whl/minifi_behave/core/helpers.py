#
#  Licensed to the Apache Software Foundation (ASF) under one or more
#  contributor license agreements.  See the NOTICE file distributed with
#  this work for additional information regarding copyright ownership.
#  The ASF licenses this file to You under the Apache License, Version 2.0
#  (the "License"); you may not use this file except in compliance with
#  the License.  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#

from __future__ import annotations

import logging
import time
import functools
from collections.abc import Callable

import docker
from minifi_behave.core.minifi_test_context import MinifiTestContext


def log_due_to_failure(context: MinifiTestContext | None):
    if context is not None:
        for container in context.containers.values():
            container.log_app_output()


def check_condition_after_wait(condition: Callable[[], bool], context: MinifiTestContext | None, wait_time: int) -> bool:
    time.sleep(wait_time)
    if not condition():
        logging.warning("Condition not met after wait")
        log_due_to_failure(context)
        return False
    return True


def wait_for_condition(condition: Callable[[], bool], timeout_seconds: float, bail_condition: Callable[[], bool],
                       context: MinifiTestContext | None) -> bool:
    if bail_condition():
        logging.warning("Bail condition evaluated to 'True', aborting wait.")
        log_due_to_failure(context)
        return False
    start_time = time.monotonic()
    try:
        while time.monotonic() - start_time < timeout_seconds:
            if condition():
                return True
            if bail_condition():
                logging.warning("Bail condition evaluated to 'True', aborting wait.")
                log_due_to_failure(context)
                return False
            remaining_time = timeout_seconds - (time.monotonic() - start_time)
            sleep_time = min(1.0, remaining_time)
            if sleep_time > 0:
                time.sleep(sleep_time)
    except Exception as ex:
        logging.warning("Exception while waiting for condition: %s", ex)
        log_due_to_failure(context)
        return False
    logging.warning("Timed out after %d seconds while waiting for condition", timeout_seconds)
    log_due_to_failure(context)
    return False


def run_cmd_in_docker_image(image_name: str, cmd: str | list, network: str) -> str:
    client = docker.from_env()
    output = client.containers.run(image=image_name,
                                   command=cmd,
                                   remove=True,
                                   stdout=True,
                                   stderr=True,
                                   network=network,
                                   detach=False)
    return output.decode("utf-8")


def run_shell_cmd_in_docker_image(image_name: str, cmd: str, network: str) -> str:
    return run_cmd_in_docker_image(image_name, ["/bin/sh", "-c", cmd], network)


def retry_check(max_tries: int = 5, retry_interval_seconds: int = 1):
    """
    Decorator for retrying a checker function that returns a boolean. The decorated function is called repeatedly until it returns True
    or the maximum number of attempts is reached. The maximum number of attempts and the interval between attempts in seconds can be configured.
    """
    def retry_check_func(func):
        @functools.wraps(func)
        def retry_wrapper(*args, **kwargs):
            for i in range(max_tries):
                if func(*args, **kwargs):
                    return True
                if i < max_tries - 1:
                    time.sleep(retry_interval_seconds)
            return False
        return retry_wrapper
    return retry_check_func
